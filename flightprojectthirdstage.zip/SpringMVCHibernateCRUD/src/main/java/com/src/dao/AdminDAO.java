package com.src.dao;

import com.src.model.Admin;

public interface AdminDAO {

	public boolean validate(Admin admin);
}
